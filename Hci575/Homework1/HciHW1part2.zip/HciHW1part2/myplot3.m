starwars = char('Phantom Menace', 'Attack of the clones', 'Revenge of the sith', 'A New Hope', 'Empire Strikes Back', 'Return of the jedi', 'The force Awakens', 'The Last Jedi', 'Rise of Skywalker');

poll = [38;23;277;309;1857;325;93;118;170]; 

pie(poll, starwars); 

title('Best Star Wars Movies Voted by Fans');




print('-dtiff','myoutput3.jpg')