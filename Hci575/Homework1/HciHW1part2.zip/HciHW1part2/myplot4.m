y = randn(500, 15); 
y2 = randn(50, 1); 
histogram(y); 


print('-dtiff','myoutput4.jpg')