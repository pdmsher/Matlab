A = diag(1:6) + diag(7:11,1)+diag(12:15,2); 
A =  A + triu(A,1)';