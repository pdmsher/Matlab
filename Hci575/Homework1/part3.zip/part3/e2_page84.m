A = [2,6;3,9];
B = [1,2;3,4]; 
C = [-5,5;5,3]; 

%-----Addition commutative-----
A + B
B + A

%-----Addition associative-----
(A + B) + C
A + (B+C)

%-----multiplication distribution----
5*(A+B)
5*A + 5*B

%-----multiplication-------
A*B
A*C
A*B
B*A
