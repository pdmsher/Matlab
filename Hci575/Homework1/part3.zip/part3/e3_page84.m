D = zeros(2, 3);
E = 5*eye(3,3); 
F = 3 * ones(2,2); 